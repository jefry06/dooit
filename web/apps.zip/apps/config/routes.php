<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$route['default_controller'] = "login";
$route['logout'] = "login/logout";
$route['term_and_condition'] = "home/term_and_condition";
$route['privacy'] = "home/privacy";
$route['logout'] = "login/logout";
$route['404_override'] = '';
