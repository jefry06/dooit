<?php
$config['login_asset_url'] = '/assets/login/';
$config['home_asset_url'] = '/assets/home/';

$config['wallet_api'] = 'http://103.43.66.52:8080/Mcoin-voucher-api/wallet/';

$config['ecommerce_api'] = 'http://103.43.66.52:8080/Mcoin-ecomerce-api/';

$config['cms_api'] = 'http://gaps.code-peeper.com/gapsadmin/api/';		
?>